%:- compile_gr($(examples)/avl/avl).
:- ['axioms.pr'].
:- ['ordered.pr'].
:- ['set.pr'].
:- ['termination.pr'].
:- ['balanced.pr'].
:- ['existence.pr'].
:- ['avl.pr'].
