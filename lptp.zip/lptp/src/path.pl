io__lptp_home('/home/staerk/lptp12').
